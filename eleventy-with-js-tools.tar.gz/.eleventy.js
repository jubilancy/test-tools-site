const fs = require("fs");
const path = require("path");

module.exports = function (eleventyConfig) {
  // Copy static assets
  eleventyConfig.addPassthroughCopy("src/css");
  eleventyConfig.addPassthroughCopy("src/js");

  // Auto-generate navigation from folder structure
  eleventyConfig.addGlobalData("nav", function () {
    const srcDir = path.join(__dirname, "src");
    const files = fs.readdirSync(srcDir, { withFileTypes: true });

    return files
      .filter((file) => file.isFile() && file.name.endsWith(".html"))
      .map((file) => ({
        title: file.name.replace(".html", "").replace(/-/g, " "),
        url: `/${file.name}`,
      }))
      .sort((a, b) => a.title.localeCompare(b.title));
  });

  return {
    dir: {
      input: "src",
      output: "_site",
      includes: "_includes",
    },
    htmlTemplateEngine: "njk",
    markdownTemplateEngine: "njk",
  };
};
